#ifndef SPLASH_SCREEN_H
#define SPLASH_SCREEN_H

// Function to display the splash screen
void splash_screen();

#endif
