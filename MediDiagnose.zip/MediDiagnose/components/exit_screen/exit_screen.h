#ifndef EXIT_SCREEN_H
#define EXIT_SCREEN_H

// Function to display the exit screen
void exit_screen();

#endif
