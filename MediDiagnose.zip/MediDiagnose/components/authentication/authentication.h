#ifndef AUTHENTICATION_H
#define AUTHENTICATION_H
#include "../../modules/utils/utils.h"

// Function to display the exit screen
void authentication_screen(User *user);

#endif
