#ifndef CONSTANTS_H
#define CONSTANTS_H

#define BOLD "\033[1m"
#define RED_COLOR "\033[31m"
#define BLUE_COLOR "\033[34m"
#define RESET_COLOR "\033[0m"
#define GREEN_COLOR "\033[32m"
#define YELLOW_COLOR "\033[33m"

#define CREATE_USER_ENDPOINT "/users"
#define FETCH_USER_ENDPOINT "/users?email=eq.%s"

#define GROQ_API_URL "https://api.groq.com/openai/v1/chat/completions"
#define GROQ_API_KEY "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"

#define BREVO_API_URL "https://api.brevo.com/v3/smtp/email"
#define BREVO_API_KEY "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"

#define SUPABASE_API_URL "https://yhfmqpdtybedmcuhgjer.supabase.co/rest/v1"
#define SUPABASE_API_KEY "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InloZm1xcGR0eWJlZG1jdWhnamVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjU5NjAwMTksImV4cCI6MjA0MTUzNjAxOX0.imirub5CacjiADpp2HZq0qdcFVjAEkN1ikE3pv4LQvM"

#endif
